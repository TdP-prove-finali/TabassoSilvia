package dao;

import db.DBConnect;
import gestisci.Model;
import gestisci.Prodotto;
import gestisci.Vendita;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ClasseDAO {
	
    public ClasseDAO(){
		}
	
	/**
	 * Inserisce un nuovo prodotto nel database.
	 * @return 
	 * */
	public  boolean inserisciProdotto(Prodotto p){
		
		String query="INSERT INTO art(COD,DESCRIZIONE,COSTO, costoOrdine, LT) VALUES(?,?,?,?,?)";
		try {
			Connection conn = DBConnect.getInstance().getConnection();
			PreparedStatement statement=conn.prepareStatement(query);
			statement.setString(1, p.getCodice().toUpperCase());
			statement.setString(2, p.getDescrizione());
			statement.setDouble(3, p.getCostoUnita());
			statement.setDouble(4, p.getCostoOrdine());
			statement.setInt(5, p.getLT());
			statement.execute();
		statement.close() ;
		conn.close();
		return true;
		
	} catch (SQLException e) {
		return false;
	}}
	
	/**
	 * Inserisce un nuvo consumo.
	 * */
	public boolean inserisciVendita(Vendita v){
		String query="INSERT INTO movim(COD,ANNO,MESE,QTA) VALUES(?,?,?,?)";
		try {
			Connection conn = DBConnect.getInstance().getConnection();
			PreparedStatement statement=conn.prepareStatement(query);
			statement.setString(1, v.getProd().getCodice());
			statement.setInt(2, v.getAnno());
			statement.setInt(3, v.getMese());
			statement.setInt(4, v.getQta());
			statement.execute();
		statement.close() ;
		conn.close();
		return true;
		
	} catch (SQLException e) {
		return false;
	}} 
	
	/**
	 * Restituisce tutti i prodotti presenti in tabella.
	 * */
	public List<Prodotto> getAllProdotti(){
		String query="SELECT * FROM art";
		List<Prodotto>prodotti=new ArrayList<Prodotto>();
		try {
			Connection conn = DBConnect.getInstance().getConnection();
			Statement statement=conn.createStatement();
			ResultSet rs=statement.executeQuery(query);
			while(rs.next()){
				Prodotto p=new Prodotto(rs.getString("cod").toUpperCase(),rs.getString("descrizione"),rs.getDouble("costo"),rs.getDouble("CostoOrdine"),rs.getInt("LT"));
				try{
					p.setQtaSconto(rs.getInt("qta_sconto"));
					p.setSconto(rs.getDouble("sconto"));
				}catch(SQLException  e){
					//per questo prodotto non esiste lo sconto non � un problema
				}
				prodotti.add(p);
		}
		statement.close() ;
		conn.close();
		
		return prodotti;
		
	} catch (SQLException e) {
		e.printStackTrace();
		throw new RuntimeException(e) ;
	}
	}
	
	/**
	 * Restituisce tutti i dati corrispondenti alle vendite.*/
	public List<Vendita> getAllVendite(){
		String query="SELECT * FROM movim";
		List<Vendita >vendite=new ArrayList<Vendita>();
		try {
			Connection conn = DBConnect.getInstance().getConnection();
			Statement statement=conn.createStatement();
			ResultSet rs=statement.executeQuery(query);
			while(rs.next()){
                Vendita v=new Vendita(rs.getString("COD").toUpperCase(), rs.getInt("QTA"),rs.getInt("ANNO"), rs.getInt("MESE"));
				vendite.add(v);
				
				}
		statement.close() ;
		conn.close();
		
		return vendite;
		
	} catch (SQLException e) {
		e.printStackTrace();
		throw new RuntimeException(e) ;
	}
	}
	
	
	
	
}
		
	
