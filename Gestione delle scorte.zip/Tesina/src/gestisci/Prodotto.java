package gestisci;

public class Prodotto implements Comparable<Prodotto> {
	
	private String codice;
	private String descrizione;
	private double costoUnita;
	private double costoOrdine;
	private int qtaSconto;
	private double sconto;
	private int LT;//  tempo misurato in mesi da quanto viene fatto l'ordine a quando viene effettuata la consegna.
	private double eoq=-1;
	
	public Prodotto(String codice) {
		super();
		this.codice = codice;
		qtaSconto=0;
		sconto=0;
		
	}
    

	public Prodotto(String codice, String descrizione, double costoUnita,
			double costoOrdine, int LT) {
		super();
		this.codice = codice;
		this.descrizione = descrizione;
		this.costoUnita = costoUnita;
		this.costoOrdine = costoOrdine;
		this.LT = LT;
		qtaSconto=0;
		sconto=0;
	}


	public Prodotto(String codice, String descrizione, double costoUnita,
			double costoOrdine, int qtaSconto, double sconto, int lT) {
		super();
		this.codice = codice;
		this.descrizione = descrizione;
		this.costoUnita = costoUnita;
		this.costoOrdine = costoOrdine;
		this.qtaSconto = qtaSconto;
		this.sconto = sconto;
		LT = lT;
	}


	public int getLT() {
		return LT;
	}


	public void setLT(int LT) {
		this.LT = LT;
	}


	public String getCodice() {
		return codice;
	}


	public void setCodice(String codice) {
		this.codice = codice;
	}


	public String getDescrizione() {
		return descrizione;
	}


	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}


	public double getCostoUnita() {
		return costoUnita;
	}


	public void setCostoUnita(double costoUnita) {
		this.costoUnita = costoUnita;
	}


	public double getCostoOrdine() {
		return costoOrdine;
	}


	public void setCostoOrdine(double costoOrdine) {
		this.costoOrdine = costoOrdine;
	}


	public int getQtaSconto() {
		return qtaSconto;
	}


	public void setQtaSconto(int qtaSconto) {
		this.qtaSconto = qtaSconto;
	}


	public double getSconto() {
		return sconto;
	}


	public void setSconto(double sconto) {
		this.sconto = sconto;
	}


	public double getEoq() {
		
		return eoq;
	}


	public void setEoq(double eoq) {
		this.eoq = eoq;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codice == null) ? 0 : codice.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Prodotto other = (Prodotto) obj;
		if (codice == null) {
			if (other.codice != null)
				return false;
		} else if (!codice.equals(other.codice))
			return false;
		return true;
	}


	
	public String toStringEsteso() {
		return "Prodotto [codice=" + codice + ", descrizione=" + descrizione
				+ " , costo unitario: "+costoUnita+" ]";
	}
	@Override
	public String toString(){
		return codice+" , "+descrizione;
	}

	@Override
	public int compareTo(Prodotto arg0) {
		
		return this.codice.compareToIgnoreCase(arg0.codice);
	}
	
	

}
