package gestisci;

public class Vendita {
	
	private Prodotto prod;
	private String codiceP;
	private int anno;
	private int mese;
	private int qta;
	
	public Vendita(Prodotto prod, int qta, int anno, int mese) {
		super();
		if(prod!=null){
		this.prod = prod;
		this.codiceP=prod.getCodice();
		this.anno = anno;
		this.mese = mese;
		this.qta = qta;
	}
		else
			throw new NullPointerException();
		}

	public Vendita(String prod, int qta, int anno, int mese) {
		super();
		
		this.codiceP = prod;
		this.anno = anno;
		this.mese = mese;
		this.qta = qta;
	}
	
	
	public Prodotto getProd() {
		return prod;
	}

	public void setProd(Prodotto prod) {
		this.prod = prod;
	}

	public int getAnno() {
		return anno;
	}

	public void setAnno(int anno) {
		this.anno = anno;
	}

	public int getMese() {
		return mese;
	}

	public void setMese(int mese) {
		this.mese = mese;
	}

	public int getQta() {
		return qta;
	}

	public void setQta(int qta) {
		this.qta = qta;
	}

	public String getCodiceP() {
		return codiceP;
	}

	public void setCodiceP(String codiceP) {
		this.codiceP = codiceP;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + anno;
		result = prime * result + mese;
		result = prime * result + ((prod == null) ? 0 : prod.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vendita other = (Vendita) obj;
		if (anno != other.anno)
			return false;
		if (mese != other.mese)
			return false;
		if (prod == null) {
			if (other.prod != null)
				return false;
		} else if (!prod.equals(other.prod))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Consumo [prod=" + prod + ", anno=" + anno + ", mese=" + mese
				+ ", qt�=" + qta + "]";
	}
	
	}


