package gestisci;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


public class Model {
	
	private Map<String, Prodotto> prodotti;
	private List<Vendita> vendite;
	private double interesse;
	
	
	public Model(){
		super();
		prodotti=new HashMap<String, Prodotto>();
		vendite=new ArrayList<Vendita>();
		interesse=0.08;
	}
	
	public Model(Map<String,Prodotto> prodotti, List<Vendita> vendite) {
		super();
		this.prodotti = prodotti;
		this.vendite = vendite;
		interesse=0.08;
		
	}

	public double getInteresse() {
		return interesse;
	}

	public void setInteresse(double interesse) {
		this.interesse = interesse;
	}
	
	/**
	 * REsituisce la lista dei prodotti*/
	public List<Prodotto> getProdotti() {
		List<Prodotto>prod=new ArrayList<Prodotto>(prodotti.values());
		return prod;
	}
	/**
	 * REsituisce la lista delle vendite*/
	public List<Vendita> getVendite() {
		return vendite;
	}

	/**
	 * Aggiunge un Prodotto alla lista dei prodotti.
	 * */
	public void addProdotto(Prodotto p){
		prodotti.put(p.getCodice(),p);
		}
	
	
	
	/**
	 * Elimina un Prodotto dalla lista dei prodotti.
	 * */
	public void removeProdotto(Prodotto p){
		prodotti.remove(p.getCodice());
		
	}
		/**
	 * Aggiunge una Vendita alla lista delle vendite.
	 * */
	public void addVendita(Vendita p){
		vendite.add(p);
		}
	public void addAllVendite(List<Vendita> v){
		for(Vendita vv:v)
			vv.setProd(prodotti.get(vv.getCodiceP())); 
		vendite.addAll(v);
		
	}
	
		/**
	 * Elimina una Vendita dalla lista delle vendite.
	 */
	public void removeVendita(Vendita p){
		int size=vendite.size();
		for(int i=0;i<size;i++){
			if(p.equals(vendite.get(i)))
				vendite.remove(i);
		}
	}
	
	/**
	 * Restituisce il prodotto corrispondente.
	 * */
	public Prodotto getProdotto(String codice){
		return prodotti.get(codice);
	}
	
	/*
	 * Restituisce la vendita corrispondente.
	 */
	public List<Vendita> getVendita(String prod){
		List<Vendita >vend=new ArrayList<Vendita>();
		for(Vendita v:vendite)
			if(v.getCodiceP().equals(prod))
		    vend.add(v);
		return vend;
	}
	
	/**
	 * Calcola la domanda media su un intervallo di un anno.
	 * */
	public double calcolaDmedioAnnuale(Prodotto p){
	
		double D=0;
		Map<Integer, Integer>vend=this.getQtaAnnuale(p);
		List<Integer> lista=new LinkedList<Integer>(vend.values())	;
		for(Integer i:lista){
			D+=i;
		}
		
		return arrotonda(D/lista.size());
	}
	
	/**
	 * Calcola la domanda media su un intervallo di un mese.
	 * */
	public double calcolaDmedioMensile(Prodotto p){
		double D=0;
		int contatore=0;
		 for(Vendita v:vendite)
			 if(v.getProd().equals(p))
			 {
				 D+=v.getQta();
				 contatore++;
			 }
		return arrotonda( D/contatore);
	}
	
	/**
	 * Restituisce una mappa avente in chiave l'anno e come valore la domanda del 
	 * prodotto e dell'anno in considerazione.
	 * */
	public Map<Integer, Integer> getQtaAnnuale(Prodotto p){
		Map<Integer, Integer> results=new HashMap<Integer,Integer>();
		
		for (Vendita v:vendite){
			if(v.getCodiceP().equals(p.getCodice())){
			
				if(results.containsKey(v.getAnno()))
				results.put(v.getAnno(), results.get(v.getAnno())+v.getQta());
				else
					results.put(v.getAnno(),v.getQta());
			}
		}
		
		return results;
	}
		
	/**
	 * Restituisce il valore del costo di magazzino relativo al singolo prodotto considerato.
	 * */
	public double calcolaH(Prodotto p){
		double c=p.getCostoUnita();
		return arrotonda(interesse*c);
			
	}
	
	/**
	 * Calcola l' Economic Order Quantity, cio� la quantit� ottimale da comprare annualmente per non avere stock out.
	 * Viene utilizzata la formula lineare, ipotizzando che la domanda sia deterministica e costante.
	 * */
	public double calcolaQ(String codice){
		return calcolaQ(prodotti.get(codice));
	}
	
	/**
	 * Calcola l' Economic Order Quantity, cio� la quantit� ottimale da comprare annualmente per non avere stock out.
	 * Viene utilizzata la formula lineare, ipotizzando che la domanda sia deterministica e costante.
	 * */
	public double calcolaQ(Prodotto questo){
		double q;
		if(questo.getEoq()==-1){
		double A=questo.getCostoOrdine();
		double D=this.calcolaDmedioAnnuale(questo);
		double h=this.calcolaH(questo);
		
		q=(2*A*D/h);
		q=Math.sqrt(q);
		if(q>D)
			q=D;
		q=arrotonda(q);
		questo.setEoq(q);
		}
		else
			q=questo.getEoq();
			
		return q;
		
	}
	public double EOQfinale(Prodotto p){
		if(p.getSconto()==0 || p.getQtaSconto()==0)
			return this.calcolaQ(p);
		if(this.TotEoq(p)<this.TotSconto(p))
			return this.calcolaQ(p);
		else
			return p.getQtaSconto();
	}
	
	/**
	 * Calcola la scorta di sicurezza; quando in magazzino si scende oltre questa soglia bisogna fare un nuovo ordine, perch� c'� il rischio di stock out.
	 * */
	public double calcolaScortaDiSicurezza(String codice){
		 return this.calcolaScortaDiSicurezza(prodotti.get(codice));}
		      
	/**
	 * Calcola la scorta di sicurezza; quando in magazzino si scende oltre questa soglia bisogna fare un nuovo ordine, perch� c'� il rischio di stock out.
	 * */
	public double calcolaScortaDiSicurezza(Prodotto questo){
		     double D=this.calcolaDmedioAnnuale(questo);
			return arrotonda(D*questo.getLT()/12);
	}
	
	/**
	 * Calcola l'impegno economico del magazzino.
	 * */
	public double calcolaMagazzino(){
			
			double totale=0;
			for(Prodotto p:this.getProdotti()){
				double h=this.calcolaH(p);
				double q=this.calcolaQ(p);
				totale+=h*q/2;
			}
				
		return arrotonda(totale);
	}
	
	/**
	 * Calcola le ordinazioni annue**/
	public int ordinazioniAnnue(Prodotto p){
		int valore=0;
		valore=(int) (this.calcolaDmedioAnnuale(p)/this.calcolaQ(p));
		if(valore==0)
			valore=1;
		return valore;
	}
	
	/**
	 * Calcola la periodicit� delle ordinazioni.*/
	public double calcolaPeriodicita(Prodotto p){
		double valore=12.0/this.ordinazioniAnnue(p);
		return arrotonda(valore);
	}
	
	public double TotSconto(Prodotto p){
		double Q=this.calcolaQ(p);
		int qta=p.getQtaSconto();
		double sconto=p.getSconto();
		double TC2=p.getCostoUnita()*calcolaDmedioAnnuale(p)*(1-sconto)+this.calcolaH(p)*qta/2+p.getCostoOrdine()*this.calcolaDmedioAnnuale(p)/qta;
		return TC2;
		}
	public double Tot(Prodotto p){
		
		if(this.TotEoq(p)<this.TotSconto(p)){
			
			return arrotonda(this.TotEoq(p));}
		else
			return arrotonda(this.TotSconto(p));
		
	}
	
	 public static double arrotonda(double value) {
	      double temp = Math.pow(10,2);
	      return Math.round(value * temp) / temp; 
	   }
	 public double TotEoq(Prodotto p){
		 double Q=this.calcolaQ(p);
		 double TCQ=p.getCostoUnita()*calcolaDmedioAnnuale(p)+this.calcolaH(p)*Q/2+p.getCostoOrdine()*this.calcolaDmedioAnnuale(p)/Q;
	     return TCQ;
	 }
	 
	 
	 
	 
}
