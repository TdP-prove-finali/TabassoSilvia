package gui;

import gestisci.Model; 

import gestisci.Prodotto;
import gestisci.Vendita;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

import dao.ClasseDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;


public class Controller {

	private ClasseDAO dao=new ClasseDAO();
	private Model model;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML //  fx:id="EOQ"
    private CheckBox EOQ; // Value injected by FXMLLoader
    
    @FXML //  fx:id="nuovoCodice"
    private TextField nuovoCodice; // Value injected by FXMLLoader

    @FXML //  fx:id="EOQtutti"
    private CheckBox EOQtutti; // Value injected by FXMLLoader

    @FXML //  fx:id="SS"
    private CheckBox SS; // Value injected by FXMLLoader

    @FXML //  fx:id="annoA"
    private TextField annoA; // Value injected by FXMLLoader

    @FXML //  fx:id="annoDa"
    private TextField annoDa; // Value injected by FXMLLoader

    @FXML //  fx:id="annoVendita"
    private TextField annoVendita; // Value injected by FXMLLoader

    @FXML //  fx:id="area"
    private TextArea area; // Value injected by FXMLLoader

    @FXML //  fx:id="codiceVendita"
    private ComboBox<Prodotto> codiceVendita; // Value injected by FXMLLoader

    @FXML //  fx:id="codiceVisualizza"
    private ComboBox<Prodotto> codiceVisualizza; // Value injected by FXMLLoader

    @FXML //  fx:id="codCons"
    private ComboBox<Prodotto> codCons; // Value injected by FXMLLoader
    
    @FXML //  fx:id="consumi"
    private CheckBox consumi; // Value injected by FXMLLoader

    @FXML //  fx:id="info"
    private CheckBox info; // Value injected by FXMLLoader

    @FXML //  fx:id="meseA"
    private TextField meseA; // Value injected by FXMLLoader

    @FXML //  fx:id="meseDa"
    private TextField meseDa; // Value injected by FXMLLoader

    @FXML //  fx:id="meseVendita"
    private TextField meseVendita; // Value injected by FXMLLoader

    @FXML //  fx:id="nuovoA"
    private TextField nuovoA; // Value injected by FXMLLoader

    @FXML //  fx:id="nuovoC"
    private TextField nuovoC; // Value injected by FXMLLoader
    
    @FXML //  fx:id="totale"
    private CheckBox totale; // Value injected by FXMLLoader

    @FXML //  fx:id="nuovoDescr"
    private TextField nuovoDescr; // Value injected by FXMLLoader

    @FXML //  fx:id="nuovoLT"
    private TextField nuovoLT; // Value injected by FXMLLoader

    @FXML //  fx:id="ordiniAnnuali"
    private CheckBox ordiniAnnuali; // Value injected by FXMLLoader

    @FXML //  fx:id="periodicita"
    private CheckBox periodicita; // Value injected by FXMLLoader

    @FXML //  fx:id="qtaVendita"
    private TextField qtaVendita; // Value injected by FXMLLoader

    @FXML //  fx:id="valoreMagazzino"
    private CheckBox valoreMagazzino; // Value injected by FXMLLoader
        
    @FXML
    void visualizza(ActionEvent event) {
    	
    	String prodo ="";
    	String result="";
    	Prodotto p=null;
    	
    	if(info.isSelected()|| EOQ.isSelected()|| SS.isSelected() ||ordiniAnnuali.isSelected() ||periodicita.isSelected() || totale.isSelected())
    	try{
    		p=codiceVisualizza.getValue();
    		prodo= p.toStringEsteso()+"\n";
    	}
    	catch(Exception e){ 
    		area.setText("Non hai inserito il codice del prodotto, di cui vuoi visualizzare le informazioni.");
			return;
    	}
    		 
    	
    	
    	
    	if(info.isSelected())
    		if(controlloCodice()){
    			result+="Domanda media annuale: "
    			+model.calcolaDmedioAnnuale(p)+",     EOQ: "+model.EOQfinale(p)+",      Scorta di Sicurezza: "
    					+ model.calcolaScortaDiSicurezza(p)+",     Sconto quantit�: "+p.getSconto()+".\n";
    		}
    		else{
    			result="Non hai inserito il codice del prodotto, di cui vuoi visualizzare le informazioni.";
    			return;
    		}
    	
    	if(EOQ.isSelected())
    		if(controlloCodice()){
    			result+="EOQ= "+model.EOQfinale(p)+".\n";
    		}
    		else{
    			result="Non hai inserito il codice del prodotto, di cui vuoi visualizzare l'EOQ.";
    			return;
    		}
    	
    	if(SS.isSelected())
    		if(controlloCodice()){
    			result+="Scorta di Sicurezza = "+model.calcolaScortaDiSicurezza(p)+".\n";
    		}
    		else{
    			result="Non hai inserito il codice del prodotto, di cui vuoi visualizzare la scorta di sicurezza.";
    			return;
    		}
    	if(ordiniAnnuali.isSelected())
    		if(controlloCodice())
    			result+="Ha ordinazioni annuali : "+model.ordinazioniAnnue(p)+".\n";
    		else{
    			result="Non hai inserito il codice del prodotto, di cui vuoi visualizzare le ordinazioni annue.";
    			return;
    		}
    			
    	if(periodicita.isSelected())
    		if(controlloCodice())
    			result+="Periodicit� con cui fare le ordinazioni: 1 ogni "+model.calcolaPeriodicita(p)
    			+" mesi oppure "+model.arrotonda((double)1/model.calcolaPeriodicita(p))+" ordinazioni in un mese.\n";
    		else{
    			result="Non hai inserito il codice del prodotto, di cui vuoi visualizzare la periodicit�.";
    			return;
    		}
    	if(totale.isSelected()){
    		
    		if(controlloCodice()){
    			
    			result+="Costo Totale: "+model.Tot(p)+".\n";
    			}
    		else
    			{result="Non hai inserito il codice del prodotto, di cui vuoi visualizzare la periodicit�.";
			return;}
    	}
    	
    	if(consumi.isSelected())
    		if((codCons.getValue()==null )){
    		if(controlloPeriodo())
    		{ 
    			if(this.MeseAnno(annoDa, meseDa)&& this.MeseAnno(annoA, meseA)){
    			result+="Consumi: \n";
    			int aDa=Integer.parseInt(annoDa.getText());
    			int aA=Integer.parseInt(annoA.getText());
    			int mDa=Integer.parseInt(meseDa.getText());
    			int mA=Integer.parseInt(meseA.getText());
    			for(Vendita v:model.getVendite())
    				if((aDa<v.getAnno()|| (aDa==v.getAnno() && mDa<=v.getMese())) &&  (aA>v.getAnno() || (aA==v.getAnno() && mA>=v.getMese())))
    					result+=v.toString()+"\n";
    		}else
    			return;
    			}
    		else{
    			for(Vendita v:model.getVendite())
    				result+=v.toString()+"\n";
    		}}
    		else{
    			if(controlloPeriodo()){ 
    				
    			if(this.MeseAnno(annoDa, meseDa)&& this.MeseAnno(annoA, meseA)){
    				int aDa=Integer.parseInt(annoDa.getText());
        			int aA=Integer.parseInt(annoA.getText());
        			int mDa=Integer.parseInt(meseDa.getText());
        			int mA=Integer.parseInt(meseA.getText());
    			result+="Consumi relativi a "+codCons.getValue().toString()+" :\n";
			    for(Vendita v:model.getVendite())
				   if(v.getProd().equals(codCons.getValue())&&(aDa<v.getAnno()|| (aDa==v.getAnno() && mDa<=v.getMese())) &&  (aA>v.getAnno() || (aA==v.getAnno() && mA>=v.getMese())))
	    				
					   result+=v.toString()+"\n";
		}
    			else
    			return;	
    			}
		else{
			for(Vendita v:model.getVendite())
				if(v.getCodiceP().equals(codCons.getValue().getCodice()))
					result+=v.toString()+"\n";
		}}
    	
    	if(valoreMagazzino.isSelected())
    		result+="Valore economico del magazzino: "+model.calcolaMagazzino()+".\n";
    	
    	if(EOQtutti.isSelected()){
    		result+="Valori calcolati per tutti i prodotti: \n";
    				for(Prodotto prodotto:model.getProdotti()){
    					double q=model.EOQfinale(prodotto);
    					result+=prodotto.toString()+" EOQ= "+q+" Scorta di sicurezza= "
    				+model.calcolaScortaDiSicurezza(prodotto)+".\n";
    					}
    	}
    	
    	area.setText(prodo+result);
    	
    	
    	    		
    }
    

    @FXML
    void nuovoProdotto(ActionEvent event) {
    	Prodotto p=null;
    	try{
    	p=new Prodotto(nuovoCodice.getText().toUpperCase(),nuovoDescr.getText(),
    			Double.parseDouble(nuovoC.getText()),
    			Double.parseDouble(nuovoA.getText()), 
    			Integer.parseInt(nuovoLT.getText()));
    	model.addProdotto(p);}
    	catch(Exception e){
    		area.setText("L'operazione non � andata a buon fine! Errore:"+ e.getMessage());
    		return;
    	}
    	if(!dao.inserisciProdotto(p))
    		area.setText("L'operazione non � andata a buon fine!");
    	else
    		area.setText("L'operazione � andata a buon fine!");
    }
    
    @FXML
    void nuovaVendita(ActionEvent event) {
    	Prodotto p=codiceVendita.getValue();
    	Vendita v=null;
    	if(this.MeseAnno(annoVendita, meseVendita)){
    		try{
    	v=new Vendita(p,Integer.parseInt(qtaVendita.getText()),Integer.parseInt(annoVendita.getText()),
    			Integer.parseInt(meseVendita.getText()));
    	
    	model.addVendita(v);}
    		catch(Exception e){
    			area.setText("L'operazione non � andata a buon fine!");
    			return;
    		}
    	if(!dao.inserisciVendita(v))
    		area.setText("L'operazione non � andata a buon fine!");
    	else
    		area.setText("L'operazione � andata a buon fine!");
    	}
    	   		
    }
    @FXML // This method is called by the FXMLLoader when initialization is complete
    public void initialize() {
        assert EOQ != null : "fx:id=\"EOQ\" was not injected: check your FXML file 'gui.fxml'.";
        assert EOQtutti != null : "fx:id=\"EOQtutti\" was not injected: check your FXML file 'gui.fxml'.";
        assert SS != null : "fx:id=\"SS\" was not injected: check your FXML file 'gui.fxml'.";
        assert annoA != null : "fx:id=\"annoA\" was not injected: check your FXML file 'gui.fxml'.";
        assert annoDa != null : "fx:id=\"annoDa\" was not injected: check your FXML file 'gui.fxml'.";
        assert annoVendita != null : "fx:id=\"annoVendita\" was not injected: check your FXML file 'gui.fxml'.";
        assert area != null : "fx:id=\"area\" was not injected: check your FXML file 'gui.fxml'.";
        assert codCons != null : "fx:id=\"codCons\" was not injected: check your FXML file 'gui.fxml'.";
        assert codiceVendita != null : "fx:id=\"codiceVendita\" was not injected: check your FXML file 'gui.fxml'.";
        assert codiceVisualizza != null : "fx:id=\"codiceVisualizza\" was not injected: check your FXML file 'gui.fxml'.";
        assert consumi != null : "fx:id=\"consumi\" was not injected: check your FXML file 'gui.fxml'.";
        assert info != null : "fx:id=\"info\" was not injected: check your FXML file 'gui.fxml'.";
        assert meseA != null : "fx:id=\"meseA\" was not injected: check your FXML file 'gui.fxml'.";
        assert meseDa != null : "fx:id=\"meseDa\" was not injected: check your FXML file 'gui.fxml'.";
        assert meseVendita != null : "fx:id=\"meseVendita\" was not injected: check your FXML file 'gui.fxml'.";
        assert nuovoA != null : "fx:id=\"nuovoA\" was not injected: check your FXML file 'gui.fxml'.";
        assert nuovoC != null : "fx:id=\"nuovoC\" was not injected: check your FXML file 'gui.fxml'.";
        assert nuovoCodice != null : "fx:id=\"nuovoCodice\" was not injected: check your FXML file 'gui.fxml'.";
        assert nuovoDescr != null : "fx:id=\"nuovoDescr\" was not injected: check your FXML file 'gui.fxml'.";
        assert nuovoLT != null : "fx:id=\"nuovoLT\" was not injected: check your FXML file 'gui.fxml'.";
        assert ordiniAnnuali != null : "fx:id=\"ordiniAnnuali\" was not injected: check your FXML file 'gui.fxml'.";
        assert periodicita != null : "fx:id=\"periodicita\" was not injected: check your FXML file 'gui.fxml'.";
        assert qtaVendita != null : "fx:id=\"qtaVendita\" was not injected: check your FXML file 'gui.fxml'.";
        assert totale != null : "fx:id=\"totale\" was not injected: check your FXML file 'gui.fxml'.";
        assert valoreMagazzino != null : "fx:id=\"valoreMagazzino\" was not injected: check your FXML file 'gui.fxml'.";

        // initialize your logic here: all @FXML variables will have been injected


    }

	public void setModel(Model model) {
		this.model = model;}
	
	public void postInizializa(){
		List<Prodotto>prodotti=new ArrayList<Prodotto>();
		prodotti.addAll(model.getProdotti());
		Collections.sort(prodotti);
		this.codCons.getItems().clear();
		codCons.getItems().addAll(prodotti);
		this.codiceVendita.getItems().clear();
		codiceVendita.getItems().addAll(prodotti);
		this.codiceVisualizza.getItems().clear();
		codiceVisualizza.getItems().addAll(prodotti);
	}
	private boolean controlloCodice(){
		return codiceVisualizza.getValue()!=null ;
	}
	private boolean controlloPeriodo(){
		return meseA.getText()!=null && !meseA.getText().isEmpty()&& meseDa.getText()!=null && !meseDa.getText().isEmpty()&& 
				annoA.getText()!=null && !annoA.getText().isEmpty()&& annoDa.getText()!=null && !annoDa.getText().isEmpty();
	}
	
	private boolean MeseAnno(TextField anno, TextField mese){
		
		try{
		int annoI=Integer.parseInt(anno.getText());
			
		}catch(NumberFormatException e){
			area.setText("Anno non corretto!Non � un valore numerico!");
			
			return false;
		}
		try{
    		int meseI=Integer.parseInt(mese.getText());
    	if(meseI<0 || meseI>12){
    		area.setText("Mese non corretto, inserisci un valore numero da 1 a 12!");
    	return false;}
    	}
    	catch(NumberFormatException e){
    		area.setText("Mese non corretto, inserisci un valore numero da 1 a 12!");
    		return false;
    	}
		return true;
	}

}
