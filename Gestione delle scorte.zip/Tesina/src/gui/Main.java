package gui;

import java.io.IOException;

import gestisci.Model;
import gestisci.Prodotto;
import gestisci.Vendita;

import java.util.List;

import dao.ClasseDAO;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/*
Copyright Silvia Tabasso

		   Licensed under the Apache License, Version 2.0 (the "License");
		   you may not use this file except in compliance with the License.
		   You may obtain a copy of the License at

		       http://www.apache.org/licenses/LICENSE-2.0

		   Unless required by applicable law or agreed to in writing, software
		   distributed under the License is distributed on an "AS IS" BASIS,
		   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		   See the License for the specific language governing permissions and
		   limitations under the License.*/

public class Main extends Application {
	
	public static void main(String[] args) {
		launch(args);
		
	}
	
	public void start(Stage primaryStage) throws IOException {

	    FXMLLoader fxmlloader= new FXMLLoader(getClass().getResource("gui.fxml"));
	    Parent root=(Parent)fxmlloader.load();
	    	   
	    Model model=this.buildModel();
	     Controller c=(Controller)fxmlloader.getController();
	  
	    c.setModel(model);
	    c.postInizializa();
		
		Scene s = new Scene(root) ;
		primaryStage.setScene(s) ;
		primaryStage.show();
	
	}

	
	
	public Model buildModel()
	{
		Model m=new Model();
		ClasseDAO dao=new ClasseDAO();
		List<Prodotto> prodotti=dao.getAllProdotti();
	    List<Vendita> vendite=dao.getAllVendite();
	    for(Prodotto p:prodotti)
	    	m.addProdotto(p);
	    
	    m.addAllVendite(vendite);
		return m;
   }

}
